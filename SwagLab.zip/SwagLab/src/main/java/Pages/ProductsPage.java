package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProductsPage extends PageBase
{
	public ProductsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(className="product_label")
	public WebElement HeaderText;
	
	
	//you can select any product by define 
	@FindBy(linkText="Sauce Labs Backpack")
	WebElement item_to_buy ;

}
