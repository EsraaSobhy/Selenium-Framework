package Pages;

public class CheckOutOverview extends PageBase
{
	public CheckOutOverview(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy (className="inventory_item_price")
	WebElement    item_price    ;
	
	@FindBy (linkText="FINISH")
	WebElement    finishBtn    ;
	
	public void FinishTransaction()
	{
		 finishBtn.click();
	}
	

}
