package Pages;

public class SelectProduct extends PageBase
{
	public ProductsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(className="inventory_details_name")
	public WebElement Product_Name;
	
	@FindBy(className="btn_primary btn_inventory")
	WebElement AddToCart;
	
	@FindBy(className="fa-layers-counter shopping_cart_badge")
	public WebElement ProductCount;
	
	@FindBy(className="cart_quantity")
	public WebElement Products_Quantity;
	
	@FindBy(linkText="CHECKOUT")
	WebElement checkout_btn;
	public void AddItemToCart()
	{
		AddToCart.click();
	}
	
	public void CheckCart()
	{
		ProductCount.click();
	}
	public void checkOut()
	{
		checkout_btn.click();
	}
	
	
}
