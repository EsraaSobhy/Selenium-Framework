package Pages;

public class CheckOut extends PageBase
{
	public ProductsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(id="first-name")
	WebElement FirstName ;
	
	@FindBy(id="last-name")
	WebElement LastName ;
	
	@FinBy(id="postal-code")
	WebElement PostalCode;
	
	@FindBy(className="btn_primary cart_button")
	WebElement ContinueBtn;
	
	
	public void CheckOutInfo(String name,String name2,String zipCode)
	{
		FirstName.sendkeys(name);
		LastName.sendkeys(name2);
		PostalCode.sendkeys(zipCode);
		ContinueBtn.click();
	}
}
