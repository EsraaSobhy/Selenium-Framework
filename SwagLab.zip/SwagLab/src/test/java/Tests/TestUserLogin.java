package Tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import Data.GetProperties;
import Pages.LoginPage;
import Pages.ProductsPage;
public class TestUserLogin extends TestBase
{
	LoginPage LoginObject;
	ProductsPage productObject;
	String user=GetProperties.LoginData.getProperty("username");
	String userPassword=GetProperties.LoginData.getProperty("password");
	
	
  @Test
  public void UserLogin()
  {
		 LoginObject=new LoginPage(driver);
		 productObject=new ProductsPage(driver);
	  LoginObject.UserLogin(user, userPassword);
	  Assert.assertEquals("Products", productObject.HeaderText.getText());
  }
}
